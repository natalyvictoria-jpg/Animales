/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author elsyj
 */
public abstract class Gato extends Animal implements Mascota {
 
    public Gato(String nombre,int edad){
        super(nombre,edad);
    }
    public void hacerSonido(){
        System.out.println(getNombre() + "dice:¡Miau miau!");
    }
    public void moverse(){
        System.out.println(getNombre() + "se mueve siglosamente.");
    }
    public void jugar(){
        System.out.println(getNombre() + "juega con un clacentin.");
    }
}
